// const readline=require('readline');
// const interface=readline.createInterface({
//     input:process.stdin,
//     output:process.stdout,
// })
// interface.question("Enter first number",(num1)=>{
//     interface.question("Enter second number",(num2)=>{
//         const num=num1+num2;
//         console.log(sum);
//     })
// })
console.log("hello raj");


